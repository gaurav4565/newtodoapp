import React from 'react';
import './App.css';
import TodoApp from '../src/component/TodoApp';


function App() {
  return (
    <div className="App">
      <TodoApp />
    </div>
  );
}

export default App;
